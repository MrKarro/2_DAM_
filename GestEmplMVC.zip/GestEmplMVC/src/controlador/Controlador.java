/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.util.ArrayList;
import modelo.Modelo;

/**
 *
 * @author Carlos
 */
public class Controlador {
    Modelo m= new Modelo();

    public void generarAleatorios(int parseInt) {
        m.generarAleatorios(parseInt);
    }

    public ArrayList<String> mostrarEmpleados() {
       return m.mostrarEmpleados();
    }
    
}
