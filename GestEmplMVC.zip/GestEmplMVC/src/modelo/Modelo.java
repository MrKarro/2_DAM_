package modelo;

import entidades.Empleado;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class Modelo implements Serializable {

    private ArrayList<Empleado> empleados;
    
    public Modelo() {
        empleados = new ArrayList<>();
    }

    public ArrayList<String> mostrarEmpleados() {   
       ArrayList<String> emp_mostrar = new ArrayList<>();
       for (Empleado emp: empleados){
           emp_mostrar.add(emp.getColumna());
       }
       return emp_mostrar;
    }

    public void generarAleatorios(int n) {
        for(int i=0; i< n; i++){
            Empleado e= new Empleado();
            e.emp_aleatorio();
            empleados.add(e);
        }
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

}
