package com.example.examenfragments_davidcarrosalinas.Modelo;

import android.provider.BaseColumns;

public class UsuarioContract implements BaseColumns {
    public static final String TABLE_NAME = "Usuarios";
    public static final String USER = "user";
    public static final String PASSWORD = "password";
    public static final String ROL = "rol";
}
