package com.example.examenfragments_davidcarrosalinas.Modelo;

import android.provider.BaseColumns;

public class LibroContract implements BaseColumns {
    public static final String TABLE_NAME = "Libros";
    public static final String ID = "id";
    public static final String TITULO = "titulo";
    public static final String AUTOR = "autor";
    public static final String NUMPAGS = "paginas";
}
