package com.example.examenfragments_davidcarrosalinas;

import com.example.examenfragments_davidcarrosalinas.Modelo.Libro;

public interface OnDialogListener {
    public void insertaLibro(Libro lib);
    public void actualizaLista(int orientacion);
}
