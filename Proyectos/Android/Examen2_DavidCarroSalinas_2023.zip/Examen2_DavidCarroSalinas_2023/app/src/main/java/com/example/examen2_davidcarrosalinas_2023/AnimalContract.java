package com.example.examen2_davidcarrosalinas_2023;

import android.provider.BaseColumns;

public class AnimalContract implements BaseColumns {

    public static final String TABLE_NAME= "Animales";
    public static final String CODIGO = "Código";
    public static final String NOMBRE = "Nombre";
    public static final String PESO = "Peso";
    public static final String TIPO = "Tipo";

}
