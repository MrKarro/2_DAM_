/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio05_herencia;



/**
 *
 * @author 6002755
 */
public class Ejercicio05_herencia {

    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
        
    }
}
