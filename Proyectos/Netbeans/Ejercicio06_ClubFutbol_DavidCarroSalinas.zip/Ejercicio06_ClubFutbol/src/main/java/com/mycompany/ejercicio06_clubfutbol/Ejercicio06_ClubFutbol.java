/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio06_clubfutbol;

/**
 *
 * @author 6002755
 */
public class Ejercicio06_ClubFutbol {

    public static void main(String[] args) {
        GestionClub gc = new GestionClub();
        gc.setVisible(true);
    }
}
