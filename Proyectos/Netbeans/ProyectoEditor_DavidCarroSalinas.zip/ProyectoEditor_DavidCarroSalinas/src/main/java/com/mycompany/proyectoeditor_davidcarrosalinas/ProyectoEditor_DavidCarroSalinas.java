/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectoeditor_davidcarrosalinas;

/**
 *
 * @author 6002755
 */
public class ProyectoEditor_DavidCarroSalinas {

    public static void main(String[] args) {
        Editor e = new Editor();
        e.setVisible(true);
    }
}
