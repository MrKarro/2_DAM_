/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio5hilos;

/**
 *
 * @author 6002755
 */
public class Cliente {
    private int articulos;

    public Cliente(int articulos) {
        this.articulos = articulos;
    }

    public int getArticulos() {
        return articulos;
    }

    public void setArticulos(int articulos) {
        this.articulos = articulos;
    }
    
    
    
}
