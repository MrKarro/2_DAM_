/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio07_herencia_jtable;

/**
 *
 * @author 6002755
 */
public class Ejercicio07_Herencia_JTable {

    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
    }
}
