/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pruebaaccesoejer08;

/**
 *
 * @author 6002755
 */
public class PruebaAccesoEjer08 {
    public static void main (String[] args){
           FlujosDeDatos f = new FlujosDeDatos();
           f.leerDisco();
           f.appendElemento();
           
           f.muestraElementos();

    }
}
