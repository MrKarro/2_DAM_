from odoo import models, fields


class Libro(models.Model):
    _name = 'biblioteca.libro'
    _description = 'Modelo para representar los libros de una biblioteca'
    name = fields.Char('Título', required=True)
    date_release = fields.Date('Fecha de publicación')
    sumario = fields.Text(string='Resumen')
    pages = fields.Integer('Páginas')
    imagen = fields.Binary(string='Imagen')
    discontinued = fields.Boolean(string='Descatalogado', readonly=True)
    language = fields.Selection([('Es', 'Español'), ('In', 'Inglés'), ('De', 'Alemán'), ('Fr', 'Francés')],
                                string='Idioma', default='Es')
    autor_ids = fields.Many2many('biblioteca.autores', string='Autores')


class Autores(models.Model):
    _name = 'biblioteca.autores'
    _description = 'modelo para representar los autores de cada libro'
    name = fields.Char('Nombre', required=True)


class Editorial(models.Model):
    _name = 'biblioteca.editorial',
    _description = 'Modelo para representar las editoriales de los libros'
    name = fields.Char('Editorial', required=True)
    direccion = fields.Text(string='Direccion', requered=True)
    población = fields.Text(string='Poblacion', required=True)
    provincia = fields.Text(string='Provincia', required=True)
    codigoPostal = fields.Integer('Codigo Postal', required=True)
    nif = fields.Text(string='Poblacion', required=True)
    logo_editorial = fields.Binary(string='Imagen')
